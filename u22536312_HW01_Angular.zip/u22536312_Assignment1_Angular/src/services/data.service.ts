import { Injectable, Inject } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { throwError } from 'rxjs';
import { Product } from '../models/product';
import { API_URL } from '../app/app.module';  // Corrected relative path

@Injectable({
  providedIn: 'root'
})
export class DataService {

  constructor(private httpClient: HttpClient, @Inject(API_URL) private apiUrl: string) { }

  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'
    })
  };

  GetProducts(): Observable<any> {
    return this.httpClient.get(`${this.apiUrl}Product/GetAllProducts`);
  }

  getAllProducts(): Observable<any> {
    return this.httpClient.get(`${this.apiUrl}Product/GetAllProducts`)
      .pipe(
        catchError(error => {
          console.error('Error details:', error);
          return throwError(() => new Error('Failed to fetch products. Please try again.'));
        })
      );
  }

  GetProductById(productId: any): Observable<Product> {
    return this.httpClient.get<Product>(`${this.apiUrl}Product/GetProductByID/${productId}`);
  }

  AddProduct(product: Product): Observable<Product> {
    return this.httpClient.post<Product>(`${this.apiUrl}Product/AddProduct`, product, this.httpOptions);
  }

  UpdateProduct(product: Product): Observable<Product> {
    return this.httpClient.put<Product>(`${this.apiUrl}Product/UpdateProduct`, product, this.httpOptions);
  }

  delete(productId: any): Observable<void> {
    return this.httpClient.delete<void>(`${this.apiUrl}Product/DeleteProduct/${productId}`, this.httpOptions);
  }
}
