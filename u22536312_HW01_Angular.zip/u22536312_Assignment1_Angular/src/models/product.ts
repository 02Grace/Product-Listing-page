export interface Product {
  productId: Number;
  name:String;
  price:number;
  description:String;
  }