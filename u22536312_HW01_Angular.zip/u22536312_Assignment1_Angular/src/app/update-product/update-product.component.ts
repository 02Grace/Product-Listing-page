import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { DataService } from '../../services/data.service';
import { Product } from '../../models/product';


@Component({
  selector: 'app-update-product',
  templateUrl: './update-product.component.html',
  styleUrl: './update-product.component.scss'
})
export class UpdateProductComponent implements OnInit {
  productForm: FormGroup;
  productId: any;
  product: any; 
  loading: boolean = true;

  constructor(
    private formBuilder: FormBuilder,
    private router: Router,
    private route: ActivatedRoute,
    private dataService: DataService
  ) {
    this.productForm = this.formBuilder.group({
      name: ['', Validators.required],
      price: ['', Validators.required],
      description: ['', Validators.required]
    });
  }

  ngOnInit(): void {
    this.productId = this.route.snapshot.paramMap.get('id');
    this.dataService.GetProductById(this.productId).subscribe(res => { 
      this.product = res;
      this.loading = false;
    });
  }

  onSubmit(): void {
    if (this.productForm.valid) {
      let updatedProduct: Product = this.productForm.value;
      updatedProduct.productId = this.productId; 
      this.dataService.UpdateProduct(updatedProduct).subscribe({
        next: (response: any) => {
          console.log("Updated Successfully", response);
          this.router.navigate(['/products']);
        },
        error: (err: any) => {
          console.error("Something went wrong", err);
          this.router.navigate(['/products']);
        }
      });
    }
  }

  onCancel(): void {
    this.router.navigate(['/products']);
  }
}

