import { NgModule, InjectionToken } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ProductListComponent } from './product-list/product-list.component';
import { AddProductComponent } from './add-product/add-product.component';
import { UpdateProductComponent } from './update-product/update-product.component';
import { DeleteProductComponent } from './delete-product/delete-product.component';

// Define the InjectionToken for the API URL
export const API_URL = new InjectionToken<string>('apiUrl', {
  providedIn: 'root',  // Makes this token available app-wide
  factory: () => 'https://localhost:7232/api/'  // Define your API base URL here
});

@NgModule({
  declarations: [
    AppComponent,
    ProductListComponent,
    AddProductComponent,
    UpdateProductComponent,
    DeleteProductComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    HttpClientModule
  ],
  providers: [
    { provide: API_URL, useValue: 'https://localhost:7232/api/' }  // Provide the API URL
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
