import { Component, OnInit, Inject } from '@angular/core';
import { Router } from '@angular/router';
import { Product } from '../../models/product';
import { DataService } from '../../services/data.service';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.scss']
})
export class ProductListComponent implements OnInit {
  products:Product[] = []

  constructor(private dataService: DataService) { }

  ngOnInit(): void {
    this.GetProducts()
    console.log(this.products)
  }

  GetProducts() {
    this.dataService.getAllProducts().subscribe(result => {
      let productList:any[] = result;
      productList.reverse().forEach((element) => {
        this.products.push(element);
      })
    });
  }
  

  onDeleteCourse(productId: any): void {
    if (confirm("Are you sure you want to delete this product?")) {
      this.dataService.delete(productId).subscribe(() => {
        this.products = this.products.filter(products => products.productId !== productId);
        this.GetProducts();
        
      }, 
      ()  => {
        location.reload();
      }
      );
    }
  }
}