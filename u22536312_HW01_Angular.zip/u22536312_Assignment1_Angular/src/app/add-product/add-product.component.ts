import { Component , OnInit, Inject } from '@angular/core';
import { FormBuilder,  FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { DataService } from '../../services/data.service';
import { Product } from '../../models/product';


@Component({
  selector: 'app-add-product',
  templateUrl: './add-product.component.html',
  styleUrl: './add-product.component.scss'
})
export class AddProductComponent  implements OnInit {
  productForm: FormGroup;
  
  constructor(@Inject(FormBuilder) private formBuilder: FormBuilder, @Inject(Router) private router: Router, @Inject(DataService) private dataService: DataService) {
    this.productForm = this.formBuilder.group({
      name: ['', Validators.required],
      price: ['', Validators.required],
      description: ['', Validators.required]
    });
  }
  


  ngOnInit(): void {
    this.productForm = this.formBuilder.group({
      name: ['', Validators.required],
     price: ['', Validators.required],
      description: ['', Validators.required]
    });
  }
  
  async onSubmit(): Promise<void> {
    if (this.productForm.valid) {
      let product: Product = this.productForm.value;
      try {
        const result: any = await this.dataService.AddProduct(product).toPromise();
        if (result.productId == 0) {
          console.error("Something went wrong");
        } else {
          console.log("Added Successfully");
        }
      } catch (error) {
        console.error("Error:", error);
      }
      this.router.navigate(['/products']);
    }
  }
  
  onCancel(): void {
    this.router.navigate(['/products']);
  }
}
