﻿using Microsoft.EntityFrameworkCore;
using u22536312_Assignment1_API.Models.Domain;

namespace u22536312_Assignment1_API.Data
{
    public class ProductDbContext : DbContext
    {
        //the constructor to initialize the DbContext with options passed
        public ProductDbContext(DbContextOptions<ProductDbContext> options) : base(options)
        {
        }

        //DbSet representing a collection of Product entities in the database
        public DbSet<Product> Products { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            //Seeding data for Product entity
            modelBuilder.Entity<Product>()
            .HasData(
                new
                {
                    ProductId = 1,
                    Name = "Running Shoes",
                    Price = 89.99m,
                    Description = "High-performance running shoes designed with breathable mesh and a cushioned sole for maximum comfort and support. Features a sleek design and double table. In addition to the traction on various surfaces."
                }
            );

            modelBuilder.Entity<Product>()
                .HasData(
                    new
                    {
                        ProductId = 2,
                        Name = "Boots",
                        Price = 89.00m,
                        Description = "Sleek leather boots with elastic side panels for easy wear. Features a comfortable insole and durable rubber outsole, ideal for everyday wear."
                    }
                );

            modelBuilder.Entity<Product>()
                .HasData(
                    new
                    {
                        ProductId = 3,
                        Name = "Baseball Cap",
                        Price = 19.99m,
                        Description = "A classic baseball cap with an adjustable strap and embroidered logo. Made of breathable cotton, perfect for casual wear and outdoor activities."
                    }
                );

            modelBuilder.Entity<Product>()
                .HasData(
                    new
                    {
                        ProductId = 4,
                        Name = "Maxi Dress",
                        Price = 59.99m,
                        Description = "Flowing, floor-length maxi dress made from lightweight fabric. Features an adjustable strap design and receiving A-line silhouette."
                    }
                );


            modelBuilder.Entity<Product>()
                .HasData(
                    new
                    {
                        ProductId = 5,
                        Name = "Slim Fit Chinos",
                        Price = 44.95m,
                        Description = "A pair of slim fit chinos made from lightweight cotton with a bit of stretch. Features a clean, modern look suitable for both work and weekend wear."
                    }
                );



            modelBuilder.Entity<Product>()
                .HasData(
                    new
                    {
                        ProductId = 6,
                        Name = "Hoodie",
                        Price = 49.99m,
                        Description = "Cozy hoodie with a bold graphic print on the front. Made of soft cotton, perfect for lounging or casual outings."
                    }
                );

        }
    }
}
