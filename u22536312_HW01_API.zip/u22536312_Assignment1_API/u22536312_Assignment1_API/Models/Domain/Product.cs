﻿using System.ComponentModel.DataAnnotations;

namespace u22536312_Assignment1_API.Models.Domain
{
    public class Product
    {
        [Key]
        public int ProductId { get; set; }

        public string? Name { get; set; }

        public decimal Price { get; set; }

        public string? Description { get; set; }
    }
}
