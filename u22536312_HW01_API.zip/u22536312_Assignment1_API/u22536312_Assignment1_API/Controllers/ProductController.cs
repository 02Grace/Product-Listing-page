﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using u22536312_Assignment1_API.Models.Domain;
using u22536312_Assignment1_API.Repository;

namespace u22536312_Assignment1_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductController : ControllerBase
    {
        //declaration of a private variable for accessing product repository
        private readonly IProductRepository _productRepository;

        //constructor to initialize the product repository
        public ProductController(IProductRepository productRepository)
        {
            _productRepository = productRepository;
        }


        //action method to get all products
        [HttpGet("GetAllProducts")]
        public async Task<IActionResult> GetAllProducts()
        {
            // try to get all products from the repository
            try
            {
                var results = await _productRepository.GetAllProductAsync();

                return Ok(results);
            }
            catch (Exception)
            {
                return StatusCode(404, "Internal Server Error. Products not retrieved.");
            }
        }

        //public async Task<IActionResult> GetAllProducts()
        //{
        //    // try to get all products from the repository
        //    try
        //    {
        //        var results = await _productRepository.GetAllProductAsync();
        //        return Ok(results);
        //    }
        //    catch (Exception)
        //    {
        //        //if something goes wrong, return an error message
        //        return NotFound("Product not found");
        //    }
        //}


        [HttpGet("GetProductByID/{ProductId}")]
        public async Task<IActionResult> GetProductByID(int ProductId)
        {
            //return Ok(await _productRepository.GetProductAsync(ProductId));

            //check if the product ID is valid
            var product = await _productRepository.GetProductAsync(ProductId);

            if (product == null)
            {
                return NotFound("Product not found.");
            }

            return Ok(product);
        }


        //action method to add a new product to the system
        [HttpPost("AddProduct")]
        public async Task<IActionResult> AddProduct(Product product)
        {
            var result = await _productRepository.InsertProductAsync(product);

            if (result.ProductId == 0)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, "Something Went Wrong");
            }

            // check if the product is null
            //if (product == null)
            //{
            //    return BadRequest("Invalid product data.");
            //}

            ////insert the product into the repository
            //var result = await _productRepository.InsertProductAsync(product);

            ////check if the product was added successfully
            //if (result.ProductId == 0)
            //{

            //    return StatusCode(StatusCodes.Status500InternalServerError, "Product could not be added. Something Went Wrong.");
            //}

            return Ok("Product added Successfully");
        }


        // action method to update an existing product
        [HttpPut("UpdateProduct")]
        public async Task<IActionResult> UpdateProduct(Product product)
        {
            await _productRepository.UpdateProductAsync(product);

            //if (product == null)
            //{
            //    return BadRequest("Invalid product data.");
            //}

            //var existingProduct = await _productRepository.GetProductAsync(product.ProductId);

            ////if the product does not exist return an error message
            //if (existingProduct == null)
            //{
            //    return NotFound("Product not found.");
            //}

            //await _productRepository.UpdateProductAsync(product);

            return Ok("Product updated Successfully");
        }


        //action method to delete a product by its ID
        [HttpDelete("DeleteProduct/{ProductId}")]
        public async Task<IActionResult> DeleteProduct(int ProductId)
        {
            var result = await _productRepository.DeleteProductAsync(ProductId);

            if (result)
            {
                return Ok("Product has been deleted Successfully");
            }

            // if the product is not found return an error message
            return NotFound("Product has not been found");
        }
    }
}
