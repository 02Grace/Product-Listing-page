﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace u22536312_Assignment1_API.Migrations
{
    /// <inheritdoc />
    public partial class InitialCreate : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Products",
                columns: table => new
                {
                    ProductId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Price = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    Description = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Products", x => x.ProductId);
                });

            migrationBuilder.InsertData(
                table: "Products",
                columns: new[] { "ProductId", "Description", "Name", "Price" },
                values: new object[,]
                {
                    { 1, "High-performance running shoes designed with breathable mesh and a cushioned sole for maximum comfort and support. Features a sleek design and double table. In addition to the traction on various surfaces.", "Running Shoes", 89.99m },
                    { 2, "Sleek leather boots with elastic side panels for easy wear. Features a comfortable insole and durable rubber outsole, ideal for everyday wear.", "Boots", 89.00m },
                    { 3, "A classic baseball cap with an adjustable strap and embroidered logo. Made of breathable cotton, perfect for casual wear and outdoor activities.", "Baseball Cap", 19.99m },
                    { 4, "Flowing, floor-length maxi dress made from lightweight fabric. Features an adjustable strap design and receiving A-line silhouette.", "Maxi Dress", 59.99m },
                    { 5, "A pair of slim fit chinos made from lightweight cotton with a bit of stretch. Features a clean, modern look suitable for both work and weekend wear.", "Slim Fit Chinos", 44.95m },
                    { 6, "Cozy hoodie with a bold graphic print on the front. Made of soft cotton, perfect for lounging or casual outings.", "Hoodie", 49.99m }
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Products");
        }
    }
}
