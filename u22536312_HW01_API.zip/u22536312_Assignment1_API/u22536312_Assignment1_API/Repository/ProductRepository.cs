﻿using Microsoft.EntityFrameworkCore;
using u22536312_Assignment1_API.Data;
using u22536312_Assignment1_API.Models.Domain;

namespace u22536312_Assignment1_API.Repository
{
    public class ProductRepository : IProductRepository // Implementing IProductRepository
    {
        private readonly ProductDbContext _productDbContext;

        public ProductRepository(ProductDbContext productDbContext)
        {
            _productDbContext = productDbContext;
        }

        public async Task<Product[]> GetAllProductAsync()
        {
            IQueryable<Product> query = _productDbContext.Products;
            return await query.ToArrayAsync();
        }

        public async Task<Product?> GetProductAsync(int ProductId)
        {
            return await _productDbContext.Products.FindAsync(ProductId);
        }

        public async Task<Product> InsertProductAsync(Product product)
        {
            _productDbContext.Products.Add(product);
            await _productDbContext.SaveChangesAsync();
            return product;
        }

        public async Task<Product> UpdateProductAsync(Product product)
        {
            _productDbContext.Entry(product).State = EntityState.Modified;
            await _productDbContext.SaveChangesAsync();
            return product;
        }

        public async Task<bool> DeleteProductAsync(int ProductId)
        {
            var product = await _productDbContext.Products.FindAsync(new object[] { ProductId });
            if (product != null)
            {
                _productDbContext.Products.Remove(product);
                await _productDbContext.SaveChangesAsync();
                return true;
            }
            return false;
        }
    }
}























//using Microsoft.EntityFrameworkCore;
//using u22536312_Assignment1_API.Data;
//using u22536312_Assignment1_API.Models.Domain;
//using u22536312_Assignment1_API.Repository;

//namespace u22536312_Assignment1_API.Repository
//{
//    public class ProductRepository
//    {
//        // private field to store the database context for accessing the product data
//        private readonly ProductDbContext _productDbContext;

//        //the constructor which is used to initialize the ProductDbContext, which is injected via dependency injection
//        public ProductRepository(ProductDbContext productDbContext)
//        {
//            _productDbContext = productDbContext;
//        }


//        // method to get all products from the database asynchronously
//        public async Task<Product[]> GetAllProductAsync()
//        {
//            IQueryable<Product> query = _productDbContext.Products;

//            return await query.ToArrayAsync();
//        }

//        // method to get a specific product by its ID asynchronously
//        public async Task<Product?> GetProductAsync(int ProductId)
//        {
//            return await _productDbContext.Products.FindAsync(ProductId);
//            //return await _productDbContext.Products.FindAsync(new object[] { ProductId });
//        }

//        // method to insert a new product into the database asynchronously
//        public async Task<Product> InsertProductAsync(Product product)
//        {
//            _productDbContext.Products.Add(product);

//            await _productDbContext.SaveChangesAsync();

//            return product;
//        }

//        // method to update an existing product in the database asynchronously
//        public async Task<Product> UpdateProductAsync(Product product)
//        {
//            _productDbContext.Entry(product).State = EntityState.Modified;

//            await _productDbContext.SaveChangesAsync();

//            return product;
//        }

//        // method to delete a product by its ID asynchronously
//        public async Task<bool> DeleteProductAsync(int ProductId)
//        {
//            //var product = await _productDbContext.Products.FindAsync(ProductId);
//            var product = await _productDbContext.Products.FindAsync(new object[] { ProductId });


//            if (product != null)
//            {
//                _productDbContext.Products.Remove(product);

//                await _productDbContext.SaveChangesAsync();

//                return true;
//            }

//            return false;
//        }
//    }
//}
