﻿using u22536312_Assignment1_API.Models.Domain;

namespace u22536312_Assignment1_API.Repository
{
    public interface IProductRepository
    {
        //the interface for the product repository defines the methods for interacting with the product data


        //Task<Product[]> GetAllProductAsync();

        Task<Product[]> GetAllProductAsync();
        Task<Product> GetProductAsync(int ProductId);
        Task<Product> InsertProductAsync(Product product);
        Task<Product> UpdateProductAsync(Product product);
        Task<bool> DeleteProductAsync(int ProductId);
    }
}
