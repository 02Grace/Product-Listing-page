﻿using Moq;
using Microsoft.AspNetCore.Mvc;
using u22536312_Assignment1_API.Repository;
using u22536312_Assignment1_API.Models.Domain;
using u22536312_Assignment1_API.Controllers;


namespace u22536312_Assignment1_API.Tests.Controller
{
    public class ProductControllerTests
    {
        
        //private Mock<IProductRepository> _mockRepository;  // Mocked repository to simulate the data layer
        //private ProductController _controller;  // The controller under test

        //// Constructor to set up the mock repository and controller
        //public ProductControllerUnitTest()
        //{
        //    _mockRepository = new Mock<IProductRepository>();  // Create a mock IProductRepository
        //    _controller = new ProductController(_mockRepository.Object);  // Pass the mock to the controller
        //}

        // Test method to verify that GetAllProducts returns an OkResult with a product array
        [Fact]
        public async Task GetAllProducts_ReturnsOkResult_WithProductArray()
        {
            // Arrange
            var mockRepository = new Mock<IProductRepository>();

            mockRepository.Setup(repo => repo.GetAllProductAsync())
                .ReturnsAsync(GetTestProducts());

            var controller = new ProductController(mockRepository.Object);


            // Act
            var result = await controller.GetAllProducts();


            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);

            Assert.Equal(200, okResult.StatusCode);


            var returnValue = Assert.IsType<Product[]>(okResult.Value);

            Assert.NotNull(returnValue);
            Assert.Equal(3, returnValue.Length);

            //var controller = new ProductController(mockRepository.Object);
            //// Arrange: Setup the mock repository to return a predefined list of products
            //_mockRepository.Setup(repo => repo.GetAllProductAsync())
            //    .ReturnsAsync(GetTestProducts());  // Returns a list of test products

            //// Act: Call the GetAllProducts method on the controller
            //var result = await _controller.GetAllProducts();

            //// Assert: Check that the result is an OkObjectResult (HTTP 200)
            //var okResult = Assert.IsType<OkObjectResult>(result);
            //Assert.Equal(200, okResult.StatusCode);  // Verify status code 200 OK

            //// Verify that the result contains the correct product array
            //var returnValue = Assert.IsType<Product[]>(okResult.Value);
            //Assert.NotNull(returnValue);  // Ensure returned products are not null
            //Assert.Equal(3, returnValue.Length);  // Ensure we have exactly 3 products in the array
        }



        // Test method to verify that GetProductByID returns an OkResult with a product
        [Fact]
        public async Task GetProductById_ReturnsOkResult_WithProduct()
        {
            // Arrange
            int testProductId = 1;
            var mockRepository = new Mock<IProductRepository>();

            mockRepository.Setup(repo => repo.GetProductAsync(testProductId))
                .ReturnsAsync(GetTestProducts()[0]);

            var controller = new ProductController(mockRepository.Object);


            // Act
            var result = await controller.GetProductByID(testProductId);


            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            Assert.Equal(200, okResult.StatusCode);

            var returnValue = Assert.IsType<Product>(okResult.Value);

            Assert.NotNull(returnValue);
            Assert.Equal(testProductId, returnValue.ProductId);

            //// Arrange: Setup the mock repository to return a specific product for a given ID
            //int testProductId = 1;
            //_mockRepository.Setup(repo => repo.GetProductAsync(testProductId))
            //    .ReturnsAsync(GetTestProducts().FirstOrDefault(p => p.ProductId == testProductId));

            //// Act: Call the GetProductByID method on the controller with the test product ID
            //var result = await _controller.GetProductByID(testProductId);

            //// Assert: Check that the result is an OkObjectResult (HTTP 200)
            //var okResult = Assert.IsType<OkObjectResult>(result);
            //Assert.Equal(200, okResult.StatusCode);  // Verify status code 200 OK

            //// Verify that the result contains the correct product
            //var returnValue = Assert.IsType<Product>(okResult.Value);
            //Assert.NotNull(returnValue);  // Ensure the returned product is not null
            //Assert.Equal(testProductId, returnValue.ProductId);  // Ensure the correct product ID is returned
        }
      
        
        // Helper method to generate a list of test products for use in the tests
        private Product[] GetTestProducts()
        {
            // Return an array of sample product objects for testing purposes
            return new Product[]
            {
                new Product
                {
                    ProductId = 1,
                    Name = "Hat",
                    Price = 69.99M,
                    Description = "Fitted cap"
                },
                new Product
                {
                    ProductId = 2,
                    Name = "Dress",
                    Price = 79.99M,
                    Description = "White and flowy"
                },
                new Product
                {
                    ProductId = 3,
                    Name = "Shoes",
                    Price = 89.99M,
                    Description = "Green and blue"
                }
            };
        }

    }
}
